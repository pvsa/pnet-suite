#! /bin/bash
echo "############################################"
echo "ACHTUNG NUR FUER DEBIAN-LINUX DISTROS !!!!!"
echo "############################################"

NOW=`date +%Y%m%d_%H%M`
ME=`whoami`
WHERE=`hostname -f`

# root rechte ?
if [ "$ME" != "root" ]; then
        echo "Keine Root-Rechte - Root Rechte werden benoetigt (sudo?) "
        exit 1
fi


## DISKS
echo "DISKS: "
echo "#############################################################################"
ls -l /dev/disk/by-id|grep part
echo "#############################################################################"
echo "#############################################################################"
echo


if [ "$1" = "" ]; then
        echo ""
        echo "Welche HDD soll gescannt werden ?"
        read HDD
else
        HDD="$1"
        # echo "Bitte HDD spezifizieren !"
        # exit 1
fi


# wenn 0 ist sie nicht gemounted, bei 1 ist gemounted
if [ $(mount|grep -c /dev/$HDD) != "0" ];

then
        echo -e "\E[47;31m ACHTUNG DEVICE IST NOCH GEMOUNTED \033[0m"
        MNT=1
else
        echo -e "\E[46;31m ACHTUNG DEVICE KANN VERAENDERT WERDEN BEIM TESTEN (fsck+badblocks) - Sicher? [Enter/Strg+C] \033[0m"
        read
        MNT=0
fi


LOG="/var/log/uchkdsk/$HDD-$NOW.log"

mkdir -p /var/log/uchkdsk

# rm -f $LOG


echo "Universal Check Disk" >> $LOG
echo "by PvSA - PILARKTO.NET v1" >> $LOG
echo "$ME@$WHERE" >> $LOG
date >> $LOG
echo "DISK ZUORDNUNG:" $HDD
#HDDLABEL=`ls -l /dev/disk/by-id/|grep $HDD` 
echo "DISK LABEL: `ls -l /dev/disk/by-id/|grep $HDD`" >> $LOG
echo "##########################################" >> $LOG

## VERSIONS OF APPS
PKML='dpkg -l'
PKMI='apt-get -qy install'


for _TOOL in $(cat ucdtools);
	do
	# teste paket
	$PKML |grep $_TOOL >> $LOG
	# wenn nicht da, installiere und logge
	if [ $? != 0 ]; then
		$PKMI $_TOOL
	# wenn istalliert loggen
	else 
		echo "$_TOOL: `$PKML |grep $_TOOL | cut -b 48-80`" >> $LOG
	fi

done





# SMART
echo "SMART CHECK"
echo "#############################################################################"
smartctl -t short -H -l selftest /dev/$HDD |tee -a $LOG
echo "#############################################################################"
echo "#############################################################################"
echo

# SENSORS
echo "SENSOR CHECK"
echo "#############################################################################"
hddtemp /dev/$HDD |tee -a $LOG
echo "#############################################################################"
echo "#############################################################################"
echo ""

# LOG CHECK 
echo "LOGFILE CHECK"
echo "#############################################################################"
cat /var/log/syslog |grep $HDD |tee -a $LOG
echo "#############################################################################"
echo "#############################################################################"
echo ""


# BADBLOCKS
echo "BADBLOCKS CHECK"
echo "#############################################################################"
touch /tmp/bad_blocks-$NOW-$HDD # damit sie nachher auch bei abbruch kein fehler erzeugt

if [ $MNT == 0 ]; then
        OPT_BB="-sv -o /tmp/bad_blocks-$NOW-$HDD"
else
        OPT_BB="-svn -o /tmp/bad_blocks-$NOW-$HDD"
fi

badblocks $OPT_BB /dev/$HDD |tee -a $LOG
echo " BADBLOCKS ARE:" |tee -a $LOG
echo "(if empty here, there are no badblocks)" |tee -a $LOG
cat /tmp/bad_blocks-$NOW-$HDD |tee -a $LOG
echo "#############################################################################"
echo "#############################################################################"
echo ""

# FSCK
echo "FSCK - Auto-detect FS-Type"
echo "#############################################################################"

OPT_FSCK="-pV"

fsck $OPT_FSCK /dev/$HDD |tee -a $LOG

echo "#############################################################################"
echo "#############################################################################"
echo ""
# evtl noch -y

echo "LogFile = /var/log/uchkdsk/$HDD-$NOW.log"
rm -f /tmp/bad_blocks-$NOW-$HDD
